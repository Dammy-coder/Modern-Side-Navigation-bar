const sideNav = document.querySelector('.navbar-container'),
bars = document.querySelector('.bars');
    bars.addEventListener('click', () => {
        sideNav.classList.toggle("active");
        bars.classList.toggle("isActive");
    });

    // Now lets check this if it is working or not;